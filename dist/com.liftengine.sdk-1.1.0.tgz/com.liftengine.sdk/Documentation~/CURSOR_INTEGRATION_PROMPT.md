# LiftEngine — One-Shot AI Integration Prompt

Copy everything inside the block below and paste it into Cursor (Agent mode) after importing **com.liftengine.sdk** and **AppLovin MAX** into the Unity project.

---

## Prompt (copy from here)

```
Integrate the LiftEngine Unity SDK (com.liftengine.sdk) with our existing AppLovin MAX ads setup.

## Goal
Route Banner, Interstitial, and Rewarded ads through LiftEngineSdk while keeping our existing MAX integration as fallback. Do not change unrelated game systems.

## Prerequisites — verify first
Before writing code, confirm:
1. Package `com.liftengine.sdk` is installed (Window → LiftEngine → Integration Manager exists)
2. Package `com.applovin.mediation.ads` is installed and MAX already initializes in the project
3. Find the main ads manager script (search: AdsManager, AdManager, MonetizationManager, MaxSdk.InitializeSdk)
4. Find the IAP manager script (search: IAPManager, PurchaseManager, ProcessPurchase, OnPurchaseSuccess)

If LiftEngineSettings.asset does not exist at Assets/Resources/LiftEngineSettings.asset:
- Tell me to open Window → LiftEngine → Integration Manager → Create Settings Asset
- STOP and wait — I will fill API key and ad unit IDs manually

## Hard rules
- MAX MUST initialize BEFORE LiftEngine. Never call LiftEngineSdk.Initialize() before MaxSdk.InitializeSdk() succeeds.
- Keep all existing business rules (cooldowns, level gates, remove-ads IAP, consent) unchanged — only swap the ad load/show layer.
- If LiftEngine settings are missing or apiKey is empty, skip LiftEngine entirely and keep current MAX behavior.
- If LiftEngine init fails, fall back to direct MaxSdk load/show — never block the player from seeing ads.
- Do NOT modify files inside Packages/com.liftengine.sdk/
- Do NOT remove existing MaxSdk callback subscriptions — they are needed for fallback.

## Integration pattern

### State flags (add to ads manager)
```csharp
private bool _liftEngineEnabled;
private bool _liftEngineReady;
private bool _liftEngineInitSettled;
private bool _liftEngineStartRequested;
private bool _liftEngineCallbacksSubscribed;
```

### Step 1 — Start LiftEngine after MAX init
In the existing MaxSdk.OnSdkInitialized / OnSdkInitialized callback (after isInitialized = true):

```csharp
TryStartLiftEngine();
if (!_liftEngineEnabled)
{
    // existing direct MAX preload calls (LoadInterstitial, LoadRewarded, etc.)
}
```

Implement TryStartLiftEngine():
```csharp
using LiftEngine;

private void TryStartLiftEngine()
{
    if (_liftEngineStartRequested) return;

    var settings = Resources.Load<LiftEngineSettings>(LiftEngineSettings.DefaultResourcePath);
    if (settings == null || string.IsNullOrWhiteSpace(settings.apiKey))
    {
        _liftEngineEnabled = false;
        Debug.Log("[AdsManager] LiftEngine disabled — missing settings or API key.");
        return;
    }

    _liftEngineStartRequested = true;
    _liftEngineEnabled = true;
    SubscribeLiftEngineCallbacks();
    LiftEngineSdk.Initialize(settings);
    ApplyLiftEngineContext();
}

private void ApplyLiftEngineContext()
{
    if (!_liftEngineEnabled) return;

#if UNITY_IOS && !UNITY_EDITOR
    // Use our existing ATT helper if we have one; otherwise skip
    if (TryGetIdfaAuthorized(out bool authorized))
        LiftEngineSdk.SetIdfaApproved(authorized);
#endif

    ApplyLiftEngineAttribution();
    LiftEngineSdk.SendReport();
}

private void ApplyLiftEngineAttribution()
{
    // Wire to our MMP — search codebase for AppsFlyer, Singular, Adjust attribution callbacks
    // installType must be "Organic" or "Non-organic"
    // mediaSource = network name from MMP, or empty string if unknown
    if (TryGetAttribution(out string installType, out string mediaSource))
        LiftEngineSdk.SetAttribution(installType, mediaSource);
}

private void SubscribeLiftEngineCallbacks()
{
    if (_liftEngineCallbacksSubscribed) return;
    LiftEngineSdkCallbacks.OnSdkInitializedEvent += OnLiftEngineSdkInitialized;
    LiftEngineSdkCallbacks.OnAdLoadedEvent += OnLiftEngineAdLoaded;
    LiftEngineSdkCallbacks.OnAdRevenuePaidEvent += OnLiftEngineAdRevenuePaid;
    LiftEngineSignalBus.AdReadyStateChanged += OnLiftEngineAdReadyStateChanged;
    _liftEngineCallbacksSubscribed = true;
}

private void OnLiftEngineSdkInitialized(LiftEngineInitializationStatus status)
{
    if (_liftEngineInitSettled) return;
    _liftEngineInitSettled = true;
    _liftEngineReady = status == LiftEngineInitializationStatus.Success;

    if (!_liftEngineReady)
    {
        Debug.LogWarning("[AdsManager] LiftEngine init failed — using direct MAX.");
        // trigger existing direct MAX preload
    }
    RefreshAdReadyState(); // call whatever method updates UI ad buttons
}

private void OnDestroy()
{
    UnsubscribeLiftEngineCallbacks(); // mirror Subscribe, use -= on same events
}
```

### Step 2 — Route IsAdReady checks
Wherever we check MaxSdk.IsInterstitialReady / IsRewardedAdReady / banner ready:
```csharp
bool ready = _liftEngineReady
    ? LiftEngineSdk.IsAdReady(LiftEngineAdFormat.Interstitial)  // or Rewarded / Banner
    : MaxSdk.IsInterstitialReady(adUnitId);
```

### Step 3 — Route Show calls
Wherever we call MaxSdk.ShowInterstitial / ShowRewardedAd / ShowBanner:
```csharp
if (_liftEngineReady && LiftEngineSdk.IsAdReady(format))
{
    LiftEngineSdk.ShowAd(format, null, new LiftEngineShowAdCallbacks
    {
        OnAdDisplayed = () => HandleAdDisplayed(format),
        OnAdHidden = () => HandleAdHidden(format),
        OnAdRewarded = () => HandleAdRewarded(format),
        OnAdDisplayFailed = msg => HandleAdDisplayFailed(format, msg)
    });
}
else
{
    // existing direct MaxSdk show call
}
```

Map HandleAdDisplayed/Hidden/Rewarded/DisplayFailed to our EXISTING interstitial/rewarded/banner callback logic — do not duplicate reward granting.

### Step 4 — Route Load calls
Wherever we call MaxSdk.LoadInterstitial / LoadRewardedAd / CreateBanner:
```csharp
if (_liftEngineReady)
    LiftEngineSdk.LoadAd(LiftEngineAdFormat.Interstitial); // or Rewarded / Banner
else
    MaxSdk.LoadInterstitial(adUnitId); // existing call
```

### Step 5 — Banner specifics
- Use LiftEngineSdk.ShowAd(LiftEngineAdFormat.Banner, ...) to show
- Use LiftEngineSdk.HideBanner() / DestroyBanner() where we currently hide/destroy MAX banner
- Do not create MAX banner directly when _liftEngineReady is true

### Step 6 — IAP hook
In IAP success handler, add ONE line:
```csharp
LiftEngineSdk.NotifyPurchase((float)purchaseAmountUsd);
```
Use localized price or USD amount — match what we already send to analytics.

### Step 7 — Attribution updates
Wherever MMP attribution callback fires, add:
```csharp
LiftEngineSdk.SetAttribution(installType, mediaSource);
LiftEngineSdk.SendReport();
```

## Deliverables
1. List every file you modified and why
2. Confirm init order: consent → MAX → LiftEngine
3. Confirm fallback paths exist for init failure and missing settings
4. Note any MMP/ATT helpers you could not find — I will wire those manually
5. Do not commit LiftEngineSettings.asset with real API keys

## Testing checklist (print for me)
- [ ] Play Mode: MAX init log, then LiftEngine init log
- [ ] Integration Manager → Ping Health (staging)
- [ ] Interstitial shows via LiftEngine
- [ ] Rewarded shows and reward grants correctly
- [ ] Banner show/hide works
- [ ] Disable apiKey in settings → direct MAX still works
```

## Prompt (copy to here)

---

## Tips 

1. **Fill settings first** — the prompt tells the AI to stop if `LiftEngineSettings.asset` is missing. Create it and add the API key before running the prompt.  
2. **Run in Agent mode** — the integration touches multiple files.  
3. **Review the diff** — especially MMP and ATT wiring; those vary per project.  
4. **Staging first** — use staging API key and Debug Mode before production.  
