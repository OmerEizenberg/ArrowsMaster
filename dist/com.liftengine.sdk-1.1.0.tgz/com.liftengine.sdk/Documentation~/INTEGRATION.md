# LiftEngine SDK — Integration Guide

This guide is for game teams integrating the LiftEngine Unity SDK with **AppLovin MAX**. It covers what you receive, what you must provide, and how to wire the SDK into your project.

---

## What LiftEngine Includes

| Component | Description |
|-----------|-------------|
| **Runtime SDK** | Unity package that optimizes ad monetization on top of AppLovin MAX |
| **Settings asset** | `LiftEngineSettings` ScriptableObject — your API key, ad unit IDs, and environment |
| **Integration Manager** | Unity Editor window: **Window → LiftEngine → Integration Manager** |
| **Sample** | Optional sample scene driver under `Samples~/BasicIntegration/` |
| **Documentation** | This guide and the one-shot AI integration prompt |

### Supported ad formats

- Banner  
- Interstitial  
- Rewarded  

### What LiftEngine handles for you

- Revenue optimization through the LiftEngine cloud service  
- Ad preloading in the background  
- Impression and context reporting to LiftEngine  
- Automatic reload after an ad is dismissed  
- Graceful fallback to standard MAX loading when LiftEngine is unavailable  

### What stays in your game code

- Consent / ATT / GDPR flows  
- AppLovin MAX SDK initialization and SDK key  
- Business rules: cooldowns, level gates, “remove ads” IAP, when to show ads  
- MMP attribution callbacks (AppsFlyer, Singular, Adjust, etc.)  
- IAP purchase notifications  

---

## Requirements

### Unity & packages

| Requirement | Minimum |
|-------------|---------|
| Unity | **2021.3 LTS** or newer |
| AppLovin MAX | **8.0+** (8.6.x tested) |
| Newtonsoft JSON | **3.2.1** (`com.unity.nuget.newtonsoft-json`) |

### From LiftEngine (we provide)

| Item | Notes |
|------|-------|
| **Unity package** | `com.liftengine.sdk` (`.tgz` or private registry) |
| **API key** | Per environment — **Staging** for QA, **Production** for live builds |

### From your team (you provide)

| Item | Where it comes from |
|------|---------------------|
| **AppLovin MAX SDK key** | AppLovin dashboard → your existing MAX integration |
| **MAX ad unit IDs** | AppLovin dashboard — Banner, Interstitial, Rewarded for **iOS and Android** |
| **Working MAX integration** | MAX must initialize successfully **before** LiftEngine |
| **MMP attribution** | Install type (`Organic` / `Non-organic`) and media source from your MMP |
| **iOS ATT state** | Whether IDFA tracking is authorized (iOS builds only) |
| **IAP hook** | Call `NotifyPurchase` when a real-money purchase completes |

---

## Package Installation

### Option A — `.tgz` file (recommended for first integration)

1. Save the file we send (e.g. `com.liftengine.sdk-1.1.0.tgz`) to a known folder.
2. Open **Window → Package Manager → + → Add package from tarball…**
3. Select the `.tgz` file.

### Option B — `manifest.json`

```json
{
  "dependencies": {
    "com.applovin.mediation.ads": "8.6.3",
    "com.unity.nuget.newtonsoft-json": "3.2.1",
    "com.liftengine.sdk": "file:../path/to/com.liftengine.sdk"
  }
}
```

### Verify installation

- **Window → LiftEngine → Integration Manager** opens without errors  
- Console shows no missing-assembly errors for `LiftEngine`  

---

## Configuration

### Step 1 — Create settings asset

1. **Window → LiftEngine → Integration Manager**  
2. **Integration** tab → **Create Settings Asset**  
3. Asset path: `Assets/Resources/LiftEngineSettings.asset` (required path)

### Step 2 — Fill in settings

| Field | Value |
|-------|-------|
| **Environment** | `Staging` for QA builds, `Production` for store builds |
| **API Key** | Key we provide (never commit production keys to public repos) |
| **iOS Banner / Interstitial / Rewarded** | Your MAX ad unit IDs |
| **Android Banner / Interstitial / Rewarded** | Your MAX ad unit IDs |
| **Auto Initialize** | **Off** — initialize from your AdsManager after MAX is ready |
| **Debug Mode** | **On** for QA only |
| **Verbose Logging** | **On** during integration, **Off** for production |

### Step 3 — MAX dashboard

No LiftEngine-specific changes are required in the AppLovin dashboard beyond your normal MAX setup. Use the same ad unit IDs in `LiftEngineSettings` that you already use with MAX.

---

## Runtime Integration Checklist

Follow this order exactly:

```
1. User consent / ATT (your existing flow)
2. MaxSdk.InitializeSdk()          ← MAX first
3. On MAX init success:
     a. LiftEngineSdk.Initialize(settings)
     b. LiftEngineSdk.SetAttribution(installType, mediaSource)
     c. LiftEngineSdk.SetIdfaApproved(bool)   ← iOS only
     d. LiftEngineSdk.SendReport()
4. Route ad calls through LiftEngineSdk (see API below)
5. On IAP success: LiftEngineSdk.NotifyPurchase(amountUsd)
6. On attribution update: SetAttribution + SendReport again
```

### Initialization example

```csharp
using LiftEngine;
using UnityEngine;

// Call from your AdsManager after MaxSdk.InitializeSdk() succeeds.
private void OnMaxSdkInitialized()
{
    var settings = Resources.Load<LiftEngineSettings>(LiftEngineSettings.DefaultResourcePath);
    if (settings == null || string.IsNullOrWhiteSpace(settings.apiKey))
    {
        // No LiftEngine — keep using direct MaxSdk calls
        return;
    }

    LiftEngineSdkCallbacks.OnSdkInitializedEvent += status =>
    {
        _liftEngineReady = status == LiftEngineInitializationStatus.Success;
        if (!_liftEngineReady)
        {
            // Fall back to direct MAX load/show
            LoadAdsViaMaxDirectly();
        }
    };

    LiftEngineSdk.Initialize(settings);

#if UNITY_IOS && !UNITY_EDITOR
    LiftEngineSdk.SetIdfaApproved(YourAttHelper.IsTrackingAuthorized());
#endif
    LiftEngineSdk.SetAttribution("Organic", "your_media_source");
    LiftEngineSdk.SendReport();
}
```

### Showing ads

Apply your business rules first, then call LiftEngine:

```csharp
if (!CanShowRewardedAd()) return;

if (_liftEngineReady && LiftEngineSdk.IsAdReady(LiftEngineAdFormat.Rewarded))
{
    LiftEngineSdk.ShowAd(LiftEngineAdFormat.Rewarded, null, new LiftEngineShowAdCallbacks
    {
        OnAdRewarded = () => GrantReward(),
        OnAdHidden = () => ResumeGameplay(),
        OnAdDisplayFailed = msg => FallbackOrRetry(msg)
    });
}
else if (_liftEngineReady)
{
    LiftEngineSdk.LoadAd(LiftEngineAdFormat.Rewarded);
}
else
{
    // Direct MAX fallback
    MaxSdk.ShowRewardedAd(rewardedAdUnitId);
}
```

### IAP hook

```csharp
// In your IAPManager when purchase succeeds:
LiftEngineSdk.NotifyPurchase((float)purchaseAmountUsd);
```

### Attribution updates

When your MMP fires an attribution callback:

```csharp
string installType = isOrganic ? "Organic" : "Non-organic";
LiftEngineSdk.SetAttribution(installType, mediaSource);
LiftEngineSdk.SendReport();
```

---

## Public API Reference

| Method | When to call |
|--------|--------------|
| `Initialize()` / `Initialize(settings)` | After MAX init succeeds |
| `IsInitialized` | Check init state |
| `SetAttribution(installType, mediaSource)` | After MMP callback; use `"Organic"` or `"Non-organic"` |
| `SetIdfaApproved(bool)` | iOS — after ATT prompt |
| `SetCountryCode(string)` | Optional manual override |
| `SendReport()` | After context changes (init, attribution, significant events) |
| `NotifyPurchase(float amountUsd)` | On successful IAP |
| `LoadAd(format)` | Preload a format |
| `IsAdReady(format)` | Before show |
| `GetPrewarmState(format)` | Debug / UI loading indicators |
| `ShowAd(format, params, callbacks)` | Display ad |
| `HideBanner()` / `DestroyBanner()` | Banner lifecycle |
| `CheckHealth(callback)` | QA — verify API connectivity |
| `SetVerboseLogging(bool)` | Enable `[LiftEngine]` logs |

### Callbacks (`LiftEngineSdkCallbacks`)

| Event | Use |
|-------|-----|
| `OnSdkInitializedEvent` | Know when routing can switch to LiftEngine |
| `OnAdLoadedEvent` | Refresh “ad ready” UI |
| `OnAdDisplayedEvent` / `OnAdHiddenEvent` | Pause / resume game |
| `OnAdRewardedEvent` | Grant reward (or use `ShowAd` callbacks) |
| `OnAdRevenuePaidEvent` | Revenue analytics |

### Optional signals (`LiftEngineSignalBus`)

```csharp
LiftEngineSignalBus.AdReadyStateChanged += signal =>
    RefreshAdButton(signal.Format, signal.IsReady);
```

---

## Fallback Behavior

LiftEngine is designed to **never block your game from showing ads**:

| Condition | Behavior |
|-----------|----------|
| Settings missing or API key empty | Skip LiftEngine; use direct MAX |
| LiftEngine init fails | Fall back to direct MAX load/show |
| Ad not ready on show | `LoadAd` + retry, or direct MAX |
| Show display failed | Your callback fires; reload via LiftEngine or MAX |

Always keep your existing direct MAX code paths as fallback during integration and in production.

---

## QA Verification

### Editor / staging

1. Set **Environment = Staging**, use staging API key  
2. Enable **Debug Mode** and **Verbose Logging**  
3. Enter Play Mode after MAX initializes  
4. **Integration Manager → Debug** tab:  
   - **Ping Health** → expect OK  
   - **Run Prewarm** → ad format reaches Ready state  
   - **Show Ad** → MAX test ad appears  

### Device build

1. Development build with staging key  
2. Filter logs for `[LiftEngine]`  
3. Confirm sequence: init → report → prewarm → show → dismiss → reload  
4. Test with airplane mode briefly — game should still show ads via MAX fallback  

---

## Firebase / GA4 analytics (recommended pattern)

LiftEngine does **not** log to Firebase directly. Your game (`AdsManager`) owns analytics so MMP and GA4 stay in one place.

| Event | When | Purpose |
|-------|------|---------|
| **`ad_viewed`** | Every ad display (or banner ILRD when no display callback) | Viewer funnel — compare to MAX **DAV** |
| **`ad_impression`** | ILRD with **revenue > 0** only | GA4 monetization + BI ad revenue |

Shared parameters on both events:

| Parameter | Values |
|-----------|--------|
| `ad_platform` | `AppLovinMAX` |
| `ad_format` | `interstitial`, `rewarded`, `banner` |
| `mediation_path` | `liftengine` or `direct_max` |
| `ad_placement` | MAX placement name when available |
| `revenue_precision` | MAX ILRD precision when available |
| `value` / `currency` | **`ad_impression` only** — USD revenue |

### Wiring

- Subscribe to **`LiftEngineSdkCallbacks.OnAdDisplayedEvent`** → log `ad_viewed` with `mediation_path=liftengine`.
- Subscribe to **`LiftEngineSdkCallbacks.OnAdRevenuePaidEvent`** → log `ad_impression` when `Revenue > 0`.
- When LiftEngine is not ready, use direct MAX callbacks the same way with `mediation_path=direct_max`.
- **Do not** double-count: when `_liftEngineReady`, ignore direct MAX ILRD callbacks for the same impression.

`LiftEngineAdInfo` exposes `Revenue`, `RevenuePrecision`, and placement metadata for your analytics layer.

---

### Before production release

- [ ] Environment = **Production**  
- [ ] Production API key in build pipeline secrets (not in git)  
- [ ] Debug Mode = **Off**  
- [ ] Verbose Logging = **Off**  
- [ ] Tested on iOS and Android device builds  
- [ ] IAP and attribution hooks verified  

---

## What to Send LiftEngine

When requesting onboarding or support, include:

| Item | Example |
|------|---------|
| Game / bundle ID | `com.studio.mygame` |
| Unity version | `2022.3.20f1` |
| MAX SDK version | `8.6.3` |
| Platforms | iOS, Android |
| MMP | AppsFlyer / Singular / Adjust |
| Staging build logs | `[LiftEngine]` lines from init through first show |
| Settings screenshot | Integration Manager (redact API key) |

**Do not send:** production API keys in email or public tickets.

---

## Support

Contact your LiftEngine account manager with:

- Unity version, MAX version, platform  
- Staging `[LiftEngine]` log excerpt  
- Description of expected vs actual behavior  

For AI-assisted integration, use **CURSOR_INTEGRATION_PROMPT.md** (included in this package).
